﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Serie1.Punto1
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {

            if (txtUser.Text.ToString().Length <= 0)
            {
                lblValida.Text = "Ingresar User";
                return;
            }
            if (txtPassword.Text.ToString().Length <=0 )
            {
                lblValida.Text = "Ingresar Password";
                return;
            }
            if (txtUser.Text.ToString().Length <=0 && txtPassword.ToString().Length <=0)
            {
                lblValida.Text = "Ingresar Credenciales";
                return;
            }
            lblValida.Text = "";
            lblmsg.Text = "Exitoso";
            limpiar();


        }
        protected void limpiar()
        {
            txtPassword.Text = "";
            txtUser.Text = "";
        }

    }
}