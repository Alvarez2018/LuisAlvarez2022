Escriba el código de una página ASPX que solicite el nombre del usuario, contraseña, y que
valide que los campos no vayan vacíos antes de enviar la solicitud al servidor.