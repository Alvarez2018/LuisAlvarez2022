Escriba un documento XML que permita intercambiar información de tarjetas de crédito
entre dos sistemas distintos: nombre del sistema, localización, número de tarjeta, ID único