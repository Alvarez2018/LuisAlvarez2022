---PROCEDIMIENTOS ALMACENADOS 
--------------------------MOSTRAR 
create proc MostrarUsuarios
as
select *from Usuarios
go
--------------------------INSERTAR 
create proc Usuarios
@nombre nvarchar (100),
@password nvarchar (100),
@rol int
as
insert into Usuarios (nombre,password,rol) values (@nombre,@password,@rol)
go
------------------------ELIMINAR
create proc EliminarUsuario
@id_user int
as
delete from Usuarios where id_user=@id_user
go
------------------EDITAR
create proc EditarUsuario
@nombre nvarchar (100),
@password nvarchar (100),
@rol int,
@id_user int
as
update Usuarios 

set nombre=@nombre, password=@password, rol=@rol
where id_user=@id_user
go